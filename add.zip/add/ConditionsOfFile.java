package add;
import java.io.File;

public interface ConditionsOfFile {
	
	boolean filterInfo(String data);

}
