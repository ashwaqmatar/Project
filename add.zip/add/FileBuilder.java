package add;
/**
 * 
 */

/**
 * @author Ali Masarweh
 *
 */
public interface FileBuilder {
	
	String Create();
	String Exit();
	String addInfo(Object Data);

}
